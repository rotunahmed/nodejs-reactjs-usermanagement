
class Controller {
    constructor() {
        const db = require('../db/db');
        this.db = db;
    }
}
module.exports = Controller